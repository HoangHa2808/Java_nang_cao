import { useState, useEffect } from "react";

import "./App.css";
import { Button, Form } from "react-bootstrap";

function App() {
	const [jobs, setJobs] = useState([]);
	const [newJob, setNewJob] = useState({
		name: "",
	});
	const [refreshFlag, setRefreshFlag] = useState({});

	// Callback chỉ chạy 1 lần duy nhất khi Component được mount vào DOM
	useEffect(() => {
		// https://localhost:7127/api/jobs
		fetch(process.env.REACT_APP_API_URL + "/jobs")
			.then((res) => res.json())
			.then((res) => {
				if (res.isSuccess) {
					setJobs(res.result);
				} else {
					alert(res.errors[0]);
				}
			});
	}, [refreshFlag]);

	function handleAddJob() {
		fetch(process.env.REACT_APP_API_URL + "/jobs", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify(newJob),
		})
			.then((res) => res.json())
			.then((res) => {
				if (res.isSuccess) {
					setNewJob({
						name: "",
					});
					setRefreshFlag({});
				} else {
					alert(res.errors[0]);
				}
			});
	}
	function handleUpdateJob(job) {
		const updateJob = {
			id: job.id,
			name: '',
		};
		updateJob.name = window.prompt("Cập nhật tên công việc", job.name);

		if (!updateJob.name) {
			return;
		}

		fetch(process.env.REACT_APP_API_URL + "/jobs/" + updateJob.id, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify(updateJob),
		})
			.then((res) => res.json())
			.then((res) => {
				if (res.isSuccess) {
					setRefreshFlag({});
				} else {
					alert(res.errors[0]);
				}
			});
	}
	function handleDeleteJob(job) {
		const isConfirm = window.confirm(
			"Bạn có chắc chắn muốn xóa công việc này!"
		);

		if (!isConfirm) {
			return;
		}

		fetch(process.env.REACT_APP_API_URL + "/jobs/" + job.id, {
			method: "DELETE",
		})
			.then((res) => res.json())
			.then((res) => {
				if (res.isSuccess) {
					setRefreshFlag({});
				} else {
					alert(res.errors[0]);
				}
			});
	}

	return (
		<div className="app">
			<div className="app-content">
				<h1 className="app-header">TODO LIST APP</h1>
				<div className="d-flex mt-3">
					<Form.Control
						className="me-2 add-job-input"
						type="text"
						placeholder="Nhập tên công việc"
						value={newJob.name}
						onChange={(e) =>
							setNewJob((prevState) => ({
								...prevState,
								name: e.target.value,
							}))
						}
					/>
					<Button variant="primary" onClick={handleAddJob}>
						Thêm
					</Button>
				</div>
				<ul className="mt-2 job-list">
					{jobs &&
						jobs.map((job) => (
							<li key={job.id} className="job-item">
								{job.name}
								<div className="d-flex job-item-actions">
									<Button
										className="me-2"
										variant="success"
										onClick={() => handleUpdateJob(job)}
									>
										Sửa
									</Button>
									<Button
										variant="danger"
										onClick={() => handleDeleteJob(job)}
									>
										Xóa
									</Button>
								</div>
							</li>
						))}
				</ul>
			</div>
		</div>
	);
}

export default App;
