﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TodoListServer.Core.Constracts;

namespace TodoListServer.Core.Entities
{
    public class Job : IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
