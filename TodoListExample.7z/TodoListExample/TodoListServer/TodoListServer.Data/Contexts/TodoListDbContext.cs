﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TodoListServer.Core.Entities;
using TodoListServer.Data.Mappings;

namespace TodoListServer.Data.Contexts
{
    public class TodoListDbContext : DbContext
    {
        public DbSet<Job> Jobs { get; set; }

        public TodoListDbContext()
        {

        }

        public TodoListDbContext(DbContextOptions<TodoListDbContext> options) : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder
                .UseSqlServer(@"Server=LAPTOP-QG81K6JN;Database=TodoListExample;Trusted_Connection=True;MultipleActiveResultSets=True;Encrypt=False");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(JobMap).Assembly);
        }
    }
}
