﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TodoListServer.Core.Entities;
using TodoListServer.Data.Contexts;

namespace TodoListServer.Data.Seeders
{
    public class DataSeeder
    {
        private readonly TodoListDbContext _dbContext;

        public DataSeeder(TodoListDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void Initialize()
        {
            _dbContext.Database.EnsureCreated();

            if (_dbContext.Jobs.Any()) return;

            IList<Job> jobs = AddJobs();
        }

        private IList<Job> AddJobs()
        {
            List<Job> jobs = new()
            {
                new() { Name = "Quét nhà" },
                new() { Name = "Lau nhà" },
                new() { Name = "Rửa bát" },
                new() { Name = "Dọn phòng" },
                new() { Name = "Học bài" },
            };

            _dbContext.Jobs.AddRange(jobs);
            _dbContext.SaveChanges();

            return jobs;
        }
    }
}
