﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TodoListServer.Core.Entities;
using TodoListServer.Data.Contexts;

namespace TodoListServer.Services.Repositories
{
    public class JobRepository
    {
        private readonly TodoListDbContext _dbContext;

        public JobRepository(TodoListDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<bool> IsNameExisted(string name, CancellationToken cancellationToken = default)
        {
            IQueryable<Job> queryable = _dbContext.Set<Job>();
            return await queryable.AnyAsync(i => i.Name.ToLower() == name.ToLower(), cancellationToken);
        }

        public async Task<IList<Job>> GetJobsAsync(CancellationToken cancellationToken = default)
        {
            IQueryable<Job> queryable = _dbContext.Set<Job>();
            return await queryable.ToListAsync(cancellationToken);
        }

        public async Task<bool> AddJobAsync(Job job, CancellationToken cancellationToken = default)
        {
            _dbContext.Jobs.Add(job);
            bool isSuccess = await _dbContext.SaveChangesAsync(cancellationToken) > 0;
            return isSuccess;
        }

        public async Task<bool> UpdateJobAsync(Job job, CancellationToken cancellationToken = default)
        {
            _dbContext.Jobs.Update(job);
            bool isSuccess = await _dbContext.SaveChangesAsync(cancellationToken) > 0;
            return isSuccess;
        }

        public async Task<bool> DeleteJobByIdAsync(int id, CancellationToken cancellationToken = default)
        {
            IQueryable<Job> queryable = _dbContext.Set<Job>();
            bool isSuccess = await queryable.Where(i => i.Id == id).ExecuteDeleteAsync(cancellationToken) > 0;
            return isSuccess;
        }
    }
}
