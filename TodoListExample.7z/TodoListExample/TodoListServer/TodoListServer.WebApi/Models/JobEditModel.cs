﻿namespace TodoListServer.WebApi.Models
{
    public class JobEditModel
    {
        public string Name { get; set; }
    }
}
