
using TodoListServer.Data.Contexts;
using TodoListServer.Data.Seeders;
using TodoListServer.WebApi.Endpoints;
using TodoListServer.WebApi.Extensions;

namespace TodoListServer.WebApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            {
                // Add services to the container
                builder.ConfigureCors()
                    .ConfigureServices()
                    .ConfigureSwaggerOpenApi();
            }

            var app = builder.Build();
            {
                // Configure the HTTP request pipeline
                app.SetupRequestPipeLine();

                // Map endpoints
                app.MapJobEndpoints();

                app.Run();
            }
        }

        public static void CreateDataSeed()
        {
            var dbContext = new TodoListDbContext();
            var seeder = new DataSeeder(dbContext);
            seeder.Initialize();
        }
    }
}