﻿using System.Net;
using TodoListServer.Core.Entities;
using TodoListServer.Services.Repositories;
using TodoListServer.WebApi.Models;

namespace TodoListServer.WebApi.Endpoints
{
    public static class JobEndpoints
    {
        public static WebApplication MapJobEndpoints(this WebApplication app)
        {
            var router = app.MapGroup("api/jobs");

            router.MapGet("/", GetJobs)
                .WithName("GetJobs")
                .Produces<ApiResponse<IList<Job>>>();

            router.MapPost("/", AddJob)
                .WithName("AddJob")
                .Accepts<Job>("application/json")
                .Produces<ApiResponse<string>>();

            router.MapPut("/{id:int}", UpdateJobById)
                .WithName("UpdateJobById")
                .Accepts<Job>("application/json")
                .Produces<ApiResponse<string>>();

            router.MapDelete("/{id:int}", DeleteJobById)
                .WithName("DeleteJobById")
                .Produces<ApiResponse<string>>();

            return app;
        }

        private static async Task<IResult> GetJobs(JobRepository repository)
        {
            try
            {
                IList<Job> jobs = await repository.GetJobsAsync();
                return Results.Ok(ApiResponse.Success(jobs));
            }
            catch (Exception err)
            {
                return Results.Ok(ApiResponse.Fail(HttpStatusCode.BadRequest, err.Message));
            }
        }

        private static async Task<IResult> AddJob(HttpRequest request, JobRepository repository)
        {
            try
            {
                var payload = await request.ReadFromJsonAsync<Job>();
                Job job = new()
                {
                    Name = payload.Name.Trim(),
                };

                if (string.IsNullOrWhiteSpace(job.Name))
                {
                    return Results.Ok(ApiResponse.Fail(HttpStatusCode.BadRequest, "Tên công việc không được để trống"));
                }

                bool isNameExisted = await repository.IsNameExisted(job.Name);
                if(isNameExisted)
                {
                    return Results.Ok(ApiResponse.Fail(HttpStatusCode.BadRequest, "Tên công việc đã tồn tại"));
                }

                bool isSuccess = await repository.AddJobAsync(job);
                if(isSuccess)
                {
                    return Results.Ok(ApiResponse.Success("Thêm công việc thành công"));
                }
                else
                {
                    return Results.Ok(ApiResponse.Fail(HttpStatusCode.NoContent, "Thêm công việc thất bại"));
                }
            }
            catch (Exception err)
            {
                return Results.Ok(ApiResponse.Fail(HttpStatusCode.BadRequest, err.Message));
            }
        }

        private static async Task<IResult> UpdateJobById(int id, HttpRequest request, JobRepository repository)
        {
            try
            {
                var payload = await request.ReadFromJsonAsync<Job>();
                Job job = new()
                {
                    Id = id,
                    Name = payload.Name.Trim(),
                };

                if (string.IsNullOrWhiteSpace(job.Name))
                {
                    return Results.Ok(ApiResponse.Fail(HttpStatusCode.BadRequest, "Tên công việc không được để trống"));
                }

                bool isNameExisted = await repository.IsNameExisted(job.Name);
                if (isNameExisted)
                {
                    return Results.Ok(ApiResponse.Fail(HttpStatusCode.BadRequest, "Tên công việc đã tồn tại"));
                }

                bool isSuccess = await repository.UpdateJobAsync(job);
                if (isSuccess)
                {
                    return Results.Ok(ApiResponse.Success("Cập nhật công việc thành công"));
                }
                else
                {
                    return Results.Ok(ApiResponse.Fail(HttpStatusCode.NoContent, "Không tìm thấy công việc cần cập nhật"));
                }
            }
            catch (Exception err)
            {
                return Results.Ok(ApiResponse.Fail(HttpStatusCode.BadRequest, err.Message));
            }
        }
       
        private static async Task<IResult> DeleteJobById(int id, JobRepository repository)
        {
            try
            {
                bool isSuccess = await repository.DeleteJobByIdAsync(id);
                if (isSuccess)
                {
                    return Results.Ok(ApiResponse.Success("Xóa công việc thành công"));
                }
                else
                {
                    return Results.Ok(ApiResponse.Fail(HttpStatusCode.NoContent, "Không tìm thấy công việc cần xóa"));
                }
            }
            catch (Exception err)
            {
                return Results.Ok(ApiResponse.Fail(HttpStatusCode.BadRequest, err.Message));
            }
        }
    }
}
